import"./api-CR-Yivd9.js";var a=r=>r&&(r.imageUrl||r.mediaUrl||r.mediaUrls?.[0]||r.galleryImages?.[0])||null;export{a as t};
