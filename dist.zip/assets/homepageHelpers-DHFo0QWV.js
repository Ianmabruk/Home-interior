import"./api-BUH8_hE9.js";var e=r=>r&&(r.imageUrl||r.mediaUrl||r.mediaUrls?.[0]||r.galleryImages?.[0]||r.beforeImages?.[0]||r.afterImages?.[0])||null;export{e as t};
